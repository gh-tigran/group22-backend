import users from "./users";

export default {
  users
}
